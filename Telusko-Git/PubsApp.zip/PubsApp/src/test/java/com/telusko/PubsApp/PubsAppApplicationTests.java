package com.telusko.PubsApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PubsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
