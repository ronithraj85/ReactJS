package com.telusko.PubsApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PubsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PubsAppApplication.class, args);
	}

}
