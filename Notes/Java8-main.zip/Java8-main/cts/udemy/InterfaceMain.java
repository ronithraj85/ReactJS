package com.cts.udemy;

public interface InterfaceMain {
    public static void main(String[] args) {
        System.out.println("Main method from inside Interface!");
    }
}
